/* Current year */
document.getElementById("year").textContent = new Date().getFullYear();

/* Header border on scroll + back-to-top button */
const header = document.getElementById("header");
const backTop = document.getElementById("backTop");

function onScroll() {
    header.classList.toggle("scrolled", window.scrollY > 10);
    backTop.classList.toggle("visible", window.scrollY > 600);
}
window.addEventListener("scroll", onScroll, { passive: true });
onScroll();

backTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
});

/* Mobile menu */
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

function setMenu(open) {
    navLinks.classList.toggle("active", open);
    menuToggle.setAttribute("aria-expanded", String(open));
    menuToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
}

menuToggle.addEventListener("click", () => {
    setMenu(!navLinks.classList.contains("active"));
});

navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => setMenu(false));
});

document.addEventListener("keydown", event => {
    if (event.key === "Escape") setMenu(false);
});

/* Scroll reveal */
const revealItems = document.querySelectorAll(".reveal");

if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12 });

    revealItems.forEach(item => observer.observe(item));
} else {
    revealItems.forEach(item => item.classList.add("show"));
}

/* =====================================================
   MOTION LAYER
   ===================================================== */

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const finePointer = window.matchMedia("(pointer: fine)").matches;

/* Scroll progress bar */
const progress = document.getElementById("progress");
window.addEventListener("scroll", () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.transform = `scaleX(${max > 0 ? window.scrollY / max : 0})`;
}, { passive: true });

/* Staggered reveal delays */
document.querySelectorAll(".projects-grid, .social-grid, .stats-grid, .skills-grid, .timeline").forEach(group => {
    group.querySelectorAll(".reveal").forEach((el, i) => el.style.setProperty("--d", (i % 3) * 0.1 + "s"));
});
document.querySelectorAll(".stat-card").forEach((el, i) => el.style.setProperty("--d", i * 0.1 + "s"));

/* Typing role */
const typingEl = document.getElementById("typing");
const roles = [
    "Agentic AI Developer",
    "Chatbot Builder",
    "WordPress Developer",
    "Graphic Designer",
    "Forex Market Analyst"
];

if (reduceMotion) {
    typingEl.textContent = roles[0];
} else {
    let r = 0, c = 0, del = false;
    (function type() {
        const word = roles[r];
        c += del ? -1 : 1;
        typingEl.textContent = word.slice(0, c);
        let wait = del ? 40 : 80;
        if (!del && c === word.length) { del = true; wait = 1600; }
        else if (del && c === 0) { del = false; r = (r + 1) % roles.length; wait = 350; }
        setTimeout(type, wait);
    })();
}

/* Animated counters */
function runCounter(el) {
    const to = +el.dataset.count;
    const from = +(el.dataset.from || 0);
    const suffix = el.dataset.suffix || "";
    if (reduceMotion) { el.textContent = to + suffix; return; }
    const t0 = performance.now();
    const dur = 1400;
    (function tick(now) {
        const p = Math.min((now - t0) / dur, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(from + (to - from) * eased) + suffix;
        if (p < 1) requestAnimationFrame(tick);
    })(t0);
}
if ("IntersectionObserver" in window) {
    const co = new IntersectionObserver(entries => {
        entries.forEach(e => {
            if (e.isIntersecting) { runCounter(e.target); co.unobserve(e.target); }
        });
    }, { threshold: 0.6 });
    document.querySelectorAll("[data-count]").forEach(el => co.observe(el));
}

if (finePointer && !reduceMotion) {

    /* 3D tilt on hero photo + parallax chips */
    const visual = document.querySelector(".hero-visual");
    const frame = document.getElementById("profileFrame");
    const chips = visual.querySelectorAll(".chip");

    visual.addEventListener("mousemove", e => {
        const r = visual.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width;
        const y = (e.clientY - r.top) / r.height;
        frame.style.transform = `rotateY(${(x - .5) * 16}deg) rotateX(${(.5 - y) * 14}deg) translateZ(10px)`;
        frame.style.setProperty("--gx", x * 100 + "%");
        frame.style.setProperty("--gy", y * 100 + "%");
        chips.forEach(chip => {
            const d = +chip.dataset.depth || 20;
            chip.style.transform = `translate(${(x - .5) * d}px, ${(y - .5) * d}px)`;
        });
    });
    visual.addEventListener("mouseleave", () => {
        frame.style.transform = "";
        chips.forEach(chip => (chip.style.transform = ""));
    });

    /* Cursor spotlight on all cards, 3D tilt on project cards */
    document.querySelectorAll(".project-card, .stat-card, .skill-category, .social-card, .timeline-content").forEach(card => {
        card.addEventListener("mousemove", e => {
            const r = card.getBoundingClientRect();
            card.style.setProperty("--mx", e.clientX - r.left + "px");
            card.style.setProperty("--my", e.clientY - r.top + "px");
            if (card.classList.contains("project-card")) {
                const x = (e.clientX - r.left) / r.width;
                const y = (e.clientY - r.top) / r.height;
                card.style.transform = `perspective(900px) rotateX(${(.5 - y) * 7}deg) rotateY(${(x - .5) * 7}deg) translateY(-3px)`;
            }
        });
        card.addEventListener("mouseleave", () => {
            if (card.classList.contains("project-card")) card.style.transform = "";
        });
    });
}

/* Network particle background */
(function () {
    if (reduceMotion) return;
    const canvas = document.getElementById("bg");
    const ctx = canvas.getContext("2d");
    let W, H, dots = [], raf;
    const mouse = { x: -999, y: -999 };

    function resize() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        W = window.innerWidth; H = window.innerHeight;
        canvas.width = W * dpr; canvas.height = H * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const n = Math.min(70, Math.floor(W / 20));
        dots = Array.from({ length: n }, () => ({
            x: Math.random() * W, y: Math.random() * H,
            vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3,
            r: Math.random() * 1.4 + .5
        }));
    }

    function draw() {
        ctx.clearRect(0, 0, W, H);
        for (let i = 0; i < dots.length; i++) {
            const a = dots[i];
            a.x += a.vx; a.y += a.vy;
            if (a.x < 0 || a.x > W) a.vx *= -1;
            if (a.y < 0 || a.y > H) a.vy *= -1;
            ctx.beginPath();
            ctx.arc(a.x, a.y, a.r, 0, 6.283);
            ctx.fillStyle = "rgba(110,200,255,.55)";
            ctx.fill();
            for (let j = i + 1; j < dots.length; j++) {
                const b = dots[j];
                const d = Math.hypot(a.x - b.x, a.y - b.y);
                if (d < 130) {
                    ctx.strokeStyle = `rgba(80,170,255,${.16 * (1 - d / 130)})`;
                    ctx.lineWidth = 1;
                    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
                }
            }
            const md = Math.hypot(a.x - mouse.x, a.y - mouse.y);
            if (md < 160) {
                ctx.strokeStyle = `rgba(113,230,237,${.3 * (1 - md / 160)})`;
                ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke();
            }
        }
        raf = requestAnimationFrame(draw);
    }

    window.addEventListener("mousemove", e => { mouse.x = e.clientX; mouse.y = e.clientY; });
    window.addEventListener("resize", resize);
    document.addEventListener("visibilitychange", () => {
        if (document.hidden) cancelAnimationFrame(raf); else draw();
    });
    resize();
    draw();
})();
